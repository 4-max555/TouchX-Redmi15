package com.touchx.sensitivity;

import android.view.MotionEvent;

// Explicit transaction IDs are required by Shizuku's destroy convention.
interface IInjector {
    boolean available() = 1;
    boolean inject(in MotionEvent event, int targetUid) = 2;
    String lastError() = 3;
    void destroy() = 16777114;
}
