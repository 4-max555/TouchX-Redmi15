package com.touchx.sensitivity;

/** Pure Java transform with independent pointer anchors. */
public final class TouchMath {
    private TouchMath() { }
    public static float scaled(float start, float position, float multiplier, float limit) {
        float result = start + (position - start) * multiplier;
        return Math.max(0f, Math.min(limit, result));
    }
}
