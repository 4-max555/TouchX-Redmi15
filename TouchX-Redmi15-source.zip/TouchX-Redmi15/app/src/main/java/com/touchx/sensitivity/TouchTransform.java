package com.touchx.sensitivity;

import android.util.SparseArray;
import android.view.InputDevice;
import android.view.MotionEvent;

/** Maintains separate anchor coordinate per pointer, preserving pointer IDs and action indexes. */
final class TouchTransform {
    private final SparseArray<float[]> anchors = new SparseArray<>();
    MotionEvent scale(MotionEvent original, float xMultiplier, float yMultiplier,
                      int screenWidth, int screenHeight) {
        final int count = original.getPointerCount();
        final int actionMasked = original.getActionMasked();
        final int actionIndex = original.getActionIndex();
        if (actionMasked == MotionEvent.ACTION_DOWN || actionMasked == MotionEvent.ACTION_CANCEL)
            anchors.clear();
        MotionEvent.PointerProperties[] properties = new MotionEvent.PointerProperties[count];
        MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[count];
        for (int i=0; i<count; i++) {
            properties[i] = new MotionEvent.PointerProperties();
            coords[i] = new MotionEvent.PointerCoords();
            original.getPointerProperties(i, properties[i]);
            original.getPointerCoords(i, coords[i]);
            final int pointerId = original.getPointerId(i);
            float[] anchor = anchors.get(pointerId);
            if (anchor == null) {
                anchor = new float[]{coords[i].x, coords[i].y};
                anchors.put(pointerId, anchor);
            }
            // A pointer-down is a new anchor for that finger only.
            if (actionMasked == MotionEvent.ACTION_POINTER_DOWN && i == actionIndex) {
                anchor[0] = coords[i].x;
                anchor[1] = coords[i].y;
            }
            coords[i].x = TouchMath.scaled(anchor[0], coords[i].x, xMultiplier, screenWidth - 1);
            coords[i].y = TouchMath.scaled(anchor[1], coords[i].y, yMultiplier, screenHeight - 1);
        }
        MotionEvent transformed = MotionEvent.obtain(original.getDownTime(), original.getEventTime(),
                original.getAction(), count, properties, coords, original.getMetaState(),
                original.getButtonState(), original.getXPrecision(), original.getYPrecision(),
                -1, original.getEdgeFlags(), InputDevice.SOURCE_TOUCHSCREEN, original.getFlags());
        if (actionMasked == MotionEvent.ACTION_UP || actionMasked == MotionEvent.ACTION_CANCEL) {
            anchors.clear();
        } else if (actionMasked == MotionEvent.ACTION_POINTER_UP) {
            anchors.remove(original.getPointerId(actionIndex));
        }
        return transformed;
    }
    void reset() { anchors.clear(); }
}
