# TouchX Redmi 15 v0.3 (safe relay test)

**Experimental, source-only Android 16 / HyperOS 3 build.**

## Why this revision exists

The earlier `setMotionEventSources(SOURCE_TOUCHSCREEN)` handler steals physical
screen events from apps. Its Shizuku availability probe only checked for an API
method, not for actual delivery. On Redmi 15, normal touch stopped working.

Android explicitly documents that listening to touchscreen `MotionEvent` via an
AccessibilityService prevents delivery to the remainder of the system:
https://developer.android.com/reference/android/accessibilityservice/AccessibilityService#onMotionEvent(android.view.MotionEvent)

## v0.3 changes

- **Fail closed:** profile interception is disabled after accessibility-service
  restarts / phone reboot / app upgrades, even if old saved profiles were enabled.
- The UI has a mandatory 5-second self-test *inside the TouchX app* before any
  game profiles can be activated. Physically tap the TouchX screen during the test.
- The test requires both a successful Shizuku injection result and a touch
  `ACTION_UP` actually delivered back into the app's own window. An injected
  event may itself be re-captured by AccessibilityService: in that case the test
  fails, interception is shut down, and the game profile **cannot** be enabled.
- The receiver calls `setMotionEventSources(0)` to restore touch on timeout,
  failed Shizuku injection, overflow, process/service shutdown, app switch, etc.
- A 3× volume-down shortcut and STOP notification provide additional ways
  to disable (notification requires user notification permission).
- Targeted Shizuku injections use Android's WAIT_FOR_RESULT mode to avoid
  treating asynchronous dispatch as delivery confirmation. There is **no**
  untargeted injection fallback.
- VersionCode 3 uses the *same* applicationId (`com.touchx.redmi15`) so it can
  update the previous Redmi 15 build instead of installing a second copy.

## How to use

1. Install APK, grant Shizuku, and enable TouchX accessibility service.
2. Open TouchX and select **3. ТЕСТ передачи касаний — 5 секунд**.
3. Tap **another blank area** of TouchX during the test (not the launch button).
4. Test status must show `Тест пройден`. If it says `НЕ пройден`, **do not** try
   to enable the game profile. The OS or Shizuku injection is unsupported.
5. Only after a passing test, select Free Fire and use X=1.2 / Y=1.1 initially,
   then check `4. Активировать игровые профили`.
6. If problems occur, immediately disable accessibility service in Android
   settings; three quick volume-down presses are a best-effort fallback.

**This does not guarantee delivery to Free Fire.** A successful self-test
validates TouchX's own window only, not the game window. Injection into apps
may be rejected by HyperOS or game security; use could violate game rules.

## GitHub Actions build

Upload `TouchX-Redmi15-safe-v0.3-source.zip` to the *root* of your repository;
use the separate supplied `build-apk.yml` at `.github/workflows/main.yml`.
The CI job unpacks the ZIP and executes `gradle :app:assembleDebug` with Java 17,
Gradle 8.9 and Android SDK 35. APK is available under the run's Artifacts.

No Android SDK or Gradle was available locally when preparing this source
archive; compilation was **not** verified locally. This is a best-effort fix.
